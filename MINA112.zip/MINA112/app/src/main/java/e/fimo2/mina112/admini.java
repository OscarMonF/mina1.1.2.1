package e.fimo2.mina112;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class admini extends AppCompatActivity{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admini);

    }

    public void conped(View view) {
        Intent i = new Intent(admini.this,AdminIni.class);
        startActivity(i);
    }

    public void elimped(View view) {
        Intent i = new Intent(admini.this,MainActivity.class);
        startActivity(i);
        finish();
    }

    public void agreim(View view) {
    }
}
