package e.fimo2.mina112.entidades;

public class usuarios {

    private String usuarios,contraseñas,usass,conss;

    public String getUsuarios() {
        return usuarios;
    }

    public void setUsuarios(String usuarios) {
        this.usuarios = usuarios;
    }

    public String getContraseñas() {
        return contraseñas;
    }

    public void setContraseñas(String contraseñas) {
        this.contraseñas = contraseñas;
    }

    public String getUsass() {
        return usass;
    }

    public void setUsass(String usass) {
        this.usass = usass;
    }

    public String getConss() {
        return conss;
    }

    public void setConss(String conss) {
        this.conss = conss;
    }
}
