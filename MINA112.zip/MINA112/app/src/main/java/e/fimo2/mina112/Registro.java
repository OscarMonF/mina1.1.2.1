package e.fimo2.mina112;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

public class Registro extends AppCompatActivity implements Response.Listener<JSONObject>, Response.ErrorListener{
    EditText nom,apat,amat,usu,con;
    ProgressDialog prog;

    RequestQueue request;
    JsonObjectRequest jsonO;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);

        nom = findViewById(R.id.Nom);
        apat = findViewById(R.id.Apat);
        amat = findViewById(R.id.Amat);
        usu = findViewById(R.id.usus);
        con = findViewById(R.id.cont);



    }

    public void regis(View view) {
        request = Volley.newRequestQueue(getApplicationContext());

        String url = "http://192.168.1.76/basemina/mina.php?nombre="+nom.getText().toString()+"&apat="+apat.getText().toString()+
                "&amat="+amat.getText().toString()+"&usus="+usu.getText().toString()+"&con="+con.getText().toString();
        url = url.replace(" ","%20");

        jsonO = new JsonObjectRequest(Request.Method.GET,url,null,this,this);

        request.add(jsonO);
    }

    @Override
    public void onErrorResponse(VolleyError error) {
        Toast.makeText(getApplicationContext(),"No se ha podido realizar el registro"+ error.toString(),Toast.LENGTH_LONG).show();
    }

    @Override
    public void onResponse(JSONObject response) {
        Toast.makeText(getApplicationContext(),"Se ha registrado correctamente",Toast.LENGTH_LONG).show();
        Intent i = new Intent(Registro.this, MainActivity.class);
        startActivity(i);
    }
}
