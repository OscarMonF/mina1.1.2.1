package e.fimo2.mina112.adapta;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

import e.fimo2.mina112.R;
import e.fimo2.mina112.entidades.pedidos;

public class pedidosadapter extends RecyclerView.Adapter<pedidosadapter.usuariosholder>{

    List<pedidos> listapedi;

    public pedidosadapter(List<pedidos> listapedi){
        this.listapedi = listapedi;
    }

    @Override
    public pedidosadapter.usuariosholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View vista = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_list,parent,false);
        RecyclerView.LayoutParams layoutParams = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        vista.setLayoutParams(layoutParams);

        return new usuariosholder(vista);
    }

    @Override
    public void onBindViewHolder(@NonNull pedidosadapter.usuariosholder holder, int position) {
        holder.a.setText(listapedi.get(position).getNo().toString());
        holder.aa.setText(listapedi.get(position).getId().toString());
        holder.aaa.setText(listapedi.get(position).getAp().toString());
        holder.aaaa.setText(listapedi.get(position).getApm().toString());
        holder.aaaaa.setText(listapedi.get(position).getIdp().toString());
        holder.aaaaaa.setText(listapedi.get(position).getCap().toString());
        holder.aaaaaaa.setText(listapedi.get(position).getFep().toString());
    }

    @Override
    public int getItemCount() {
        return listapedi.size();
    }

    public  class usuariosholder extends RecyclerView.ViewHolder{

        TextView a,aa,aaa,aaaa,aaaaa,aaaaaa,aaaaaaa;

        public usuariosholder(View itemView) {
            super(itemView);

            a = itemView.findViewById(R.id.nomped);
            aa = itemView.findViewById(R.id.idpec);
            aaa = itemView.findViewById(R.id.apeped);
            aaaa = itemView.findViewById(R.id.apemped);
            aaaaa = itemView.findViewById(R.id.idproped);
            aaaaaa = itemView.findViewById(R.id.cantped);
            aaaaaaa = itemView.findViewById(R.id.feped);
        }
    }
}
