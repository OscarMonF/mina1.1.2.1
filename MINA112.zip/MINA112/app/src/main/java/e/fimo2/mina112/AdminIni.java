package e.fimo2.mina112;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import e.fimo2.mina112.adapta.pedidosadapter;
import e.fimo2.mina112.entidades.pedidos;

public class AdminIni extends AppCompatActivity implements Response.Listener<JSONObject>, Response.ErrorListener{

    RecyclerView recyclerpedidos;
    ArrayList<pedidos> listapedidos;
    EditText idelim;

    RequestQueue request;
    JsonObjectRequest jsonO;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_ini);

        listapedidos = new ArrayList<>();

        idelim = findViewById(R.id.idelimo);

        recyclerpedidos = findViewById(R.id.Recyped);
        recyclerpedidos.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL,false));


        cargar();
    }

    private void cargar() {
        request = Volley.newRequestQueue(getApplicationContext());
        String url="http://192.168.1.76/basemina/conped.php";

        jsonO = new JsonObjectRequest(Request.Method.GET,url,null,this,this);

        request.add(jsonO);
    }

    @Override
    public void onErrorResponse(VolleyError error) {
        Intent i = new Intent(AdminIni.this,admini.class);
        startActivity(i);
        finish();
    }

    @Override
    public void onResponse(JSONObject response) {
        pedidos ped = null;

        JSONArray json = response.optJSONArray("usuarios");
        try {
            for (int i=0; i<=json.length();i++){
                ped = new pedidos();
                JSONObject jsonObject = null;
                jsonObject = json.getJSONObject(i);

                ped.setId(jsonObject.optString("id"));
                ped.setNo(jsonObject.optString("nombre"));
                ped.setAp(jsonObject.optString("apat"));
                ped.setApm(jsonObject.optString("amat"));
                ped.setFep(jsonObject.optString("fec"));
                ped.setIdp(jsonObject.optString("idpro"));
                ped.setCap(jsonObject.optString("cantidad"));
                listapedidos.add(ped);
                pedidosadapter adap = new pedidosadapter(listapedidos);
                recyclerpedidos.setAdapter(adap);
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public void elimin(View view) {
        request = Volley.newRequestQueue(getApplicationContext());

        String url = "http://192.168.1.76/basemina/bajaped.php?idped="+idelim.getText().toString();

        jsonO = new JsonObjectRequest(Request.Method.GET,url,null,this,this);

        request.add(jsonO);
    }
}
