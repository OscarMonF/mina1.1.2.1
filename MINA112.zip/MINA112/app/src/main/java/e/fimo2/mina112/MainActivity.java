package e.fimo2.mina112;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import e.fimo2.mina112.entidades.usuarios;

public class MainActivity extends AppCompatActivity implements Response.Listener<JSONObject>, Response.ErrorListener {

    EditText usuario,contraseña;

    RequestQueue request;
    JsonObjectRequest jsonO;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        usuario = findViewById(R.id.usu);
        contraseña = findViewById(R.id.con);
    }

    public void regi(View view) {
        Intent i = new Intent(MainActivity.this, Registro.class);
        startActivity(i);
        finish();
    }

    public void inic(View view) {
        request = Volley.newRequestQueue(getApplicationContext());

        String url = "http://192.168.1.76/basemina/consulta.php?usus="+usuario.getText().toString()+"&con="+contraseña.getText().toString();
        url = url.replace(" ","%20");

        jsonO = new JsonObjectRequest(Request.Method.GET,url,null,this,this);

        request.add(jsonO);
    }

    @Override
    public void onErrorResponse(VolleyError error) {
        Toast.makeText(getApplicationContext(),"Usuario o contraseña incorrectos",Toast.LENGTH_LONG).show();
    }

    @Override
    public void onResponse(JSONObject response) {

        usuarios entrar = new usuarios();

        JSONArray json = response.optJSONArray("usuarios");
        JSONObject jsonObject = null;

        try {
            jsonObject = json.getJSONObject(0);
            entrar.setUsuarios(jsonObject.optString("usus"));
            entrar.setContraseñas(jsonObject.optString("con"));
            entrar.setUsass(jsonObject.optString("apat"));
            entrar.setConss(jsonObject.optString("amat"));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        String usuarioss = entrar.getUsuarios();
        if (usuarioss != "" && entrar.getContraseñas() != ""){
            Intent i = new Intent(MainActivity.this, InicioAdmin.class);
            startActivity(i);
            finish();
        }
        else{
            if (entrar.getUsass() != "" && entrar.getConss() != ""){
                Intent i = new Intent(MainActivity.this, admini.class);
                startActivity(i);
                finish();
            }
            else {
                Toast.makeText(getApplicationContext(), "Usuario o contraseña incorrectos", Toast.LENGTH_LONG).show();
            }
        }
    }

    public void admi(View view) {
        Intent i = new Intent(MainActivity.this,admini.class);
        startActivity(i);
        finish();
    }
}
